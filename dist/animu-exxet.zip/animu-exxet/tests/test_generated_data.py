from __future__ import annotations

import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
GENERATED = ROOT / "data/generated"
MANIFEST = ROOT / "module.json"
DIST_ZIP = ROOT / "dist/animu-exxet.zip"
PACKS = ROOT / "packs"


def load_json(path: Path | str):
    if isinstance(path, str):
        path = GENERATED / path
    return json.loads(path.read_text(encoding="utf-8"))


def expected_token_dimensions(size_value: int | None) -> float:
    if size_value is None or size_value <= 0:
        return 1
    if size_value <= 3:
        return 0.25
    if size_value <= 8:
        return 0.5
    if size_value <= 22:
        return 1
    if size_value <= 24:
        return 2
    if size_value <= 28:
        return 3
    if size_value <= 33:
        return 4
    return 5


class GeneratedDataTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.index = load_json("index.json")
        cls.records = {
            dataset["id"]: load_json(dataset["recordsFilename"])
            for dataset in cls.index["datasets"]
        }
        cls.datasets = {
            dataset["id"]: load_json(dataset["filename"])
            for dataset in cls.index["datasets"]
        }
        cls.manifest = load_json(MANIFEST)

    def test_index_lists_expected_books(self):
        dataset_ids = [dataset["id"] for dataset in self.index["datasets"]]
        self.assertEqual(
            dataset_ids,
            [
                "core-exxet",
                "caminaron-con-nosotros",
                "complemento-web-vol-1",
                "guia-del-mundo-perfecto",
                "dramatis-personae",
                "dramatis-personae-vol-2",
                "pantalla-del-director",
                "dravenor-parte-1",
                "dravenor-parte-2",
                "dravenor-parte-3",
            ],
        )

    def test_record_counts_are_reasonable(self):
        minimums = {
            "core-exxet": 20,
            "caminaron-con-nosotros": 80,
            "complemento-web-vol-1": 5,
            "guia-del-mundo-perfecto": 15,
            "dramatis-personae": 10,
            "dramatis-personae-vol-2": 10,
            "pantalla-del-director": 25,
            "dravenor-parte-1": 5,
            "dravenor-parte-2": 5,
            "dravenor-parte-3": 3,
        }
        for dataset_id, minimum in minimums.items():
            with self.subTest(dataset_id=dataset_id):
                self.assertGreaterEqual(self.records[dataset_id]["count"], minimum)

    def test_known_entries_present(self):
        expected_names = {
            "core-exxet": {
                "Lagor (Araña Psíquica)",
                "Nezuacuatil (Enjambre de cucarachas)",
                "Dragón (Antiguo)",
                "Zombi",
            },
            "caminaron-con-nosotros": {
                "Abominación (Semilla Primigenia)",
                "Balzak (Sacerdote)",
                "Portador (Menor)",
                "Señor de los Muertos (No muerto supremo)",
            },
            "dramatis-personae": {
                "XII",
                "Kali",
                "El Coronel",
            },
            "dramatis-personae-vol-2": {
                "Balthassar, el Monstruo",
                "Killrayne, Ejecutor Imperial Supremo",
                "Matthew Gaul, Arconte Supremo",
            },
            "pantalla-del-director": {
                "Faust Orbatos",
                "Shion Demeter",
                "Raptor el Ejecutor Oscuro",
            },
            "dravenor-parte-1": {
                "Araña de Tierra (La Máquina · Varna menor)",
                "Colosal (La Máquina · Varna mayor)",
            },
        }
        for dataset_id, names in expected_names.items():
            dataset_names = {record["name"] for record in self.records[dataset_id]["records"]}
            for name in names:
                with self.subTest(dataset_id=dataset_id, name=name):
                    self.assertIn(name, dataset_names)

    def test_no_remaining_extraction_warnings(self):
        for dataset_id, data in self.records.items():
            with self.subTest(dataset_id=dataset_id):
                self.assertEqual(data["warningCount"], 0)

    def test_notes_are_embedded_for_unmapped_fields(self):
        core_first = self.datasets["core-exxet"]["documents"][0]
        self.assertTrue(core_first["system"]["general"]["notes"])
        self.assertEqual(core_first["system"]["general"]["notes"][0]["type"], "note")

        dramatic = next(
            document
            for document in self.datasets["dramatis-personae"]["documents"]
            if document["name"] == "XII"
        )
        note_names = [note["name"] for note in dramatic["system"]["general"]["notes"]]
        self.assertTrue(any(name.startswith("Ki:") for name in note_names))
        self.assertTrue(any(name.startswith("Técnicas:") for name in note_names))

    def test_manifest_is_installable_from_github(self):
        self.assertEqual(self.manifest["id"], "animu-exxet")
        self.assertEqual(self.manifest["version"], "0.2.6")
        self.assertTrue(DIST_ZIP.exists())
        self.assertEqual(
            self.manifest["manifest"],
            "https://raw.githubusercontent.com/tisken/caminarus-exxet/main/module.json",
        )
        self.assertEqual(
            self.manifest["download"],
            "https://raw.githubusercontent.com/tisken/caminarus-exxet/main/dist/animu-exxet.zip",
        )
        dependency = self.manifest["relationships"]["systems"][0]
        self.assertEqual(dependency["id"], "animabf")
        self.assertIn("manifest", dependency)

    def test_manifest_uses_runtime_compendium_population(self):
        self.assertEqual(self.manifest["packs"], [])

    def test_pack_directories_match_generated_counts(self):
        pack_dir = PACKS / "creatures-exxet"
        self.assertTrue(pack_dir.exists())

        entries = sorted(pack_dir.glob("*.json"))
        actor_entries = [path for path in entries if path.name.startswith("character_")]
        folder_entries = [path for path in entries if path.name.startswith("folders_")]

        self.assertEqual(len(folder_entries), len(self.index["datasets"]) + 1)
        self.assertEqual(
            len(actor_entries),
            sum(dataset["count"] for dataset in self.index["datasets"]),
        )

        folders = [json.loads(path.read_text(encoding="utf-8")) for path in folder_entries]
        folder_ids = {folder["_id"] for folder in folders}
        root_folder = next(folder for folder in folders if folder["name"] == "Creatures Exxet")
        child_folders = [folder for folder in folders if folder["_id"] != root_folder["_id"]]
        self.assertIsNone(root_folder["folder"])
        self.assertEqual(
            {folder["name"] for folder in child_folders},
            {dataset["label"] for dataset in self.index["datasets"]},
        )
        self.assertTrue(all(folder["folder"] == root_folder["_id"] for folder in child_folders))

        sample = json.loads(actor_entries[0].read_text(encoding="utf-8"))
        self.assertEqual(sample["type"], "character")
        self.assertIn("_id", sample)
        self.assertEqual(sample["ownership"]["default"], 0)
        self.assertEqual(sample["_stats"]["systemId"], "animabf")
        self.assertIn(sample["folder"], folder_ids)
        self.assertIn("texture", sample["prototypeToken"])
        self.assertIn("light", sample["prototypeToken"])
        self.assertEqual(sample["prototypeToken"]["texture"]["src"], sample["img"])
        self.assertEqual(
            sample["flags"]["cf"]["path"].split("#/CF_SEP/")[0],
            "Creatures Exxet",
        )

        for actor_path in actor_entries:
            actor = json.loads(actor_path.read_text(encoding="utf-8"))
            size_value = actor["system"]["general"]["aspect"]["size"]["value"]
            expected_dimensions = expected_token_dimensions(size_value)
            with self.subTest(actor=actor["name"], size_value=size_value):
                self.assertEqual(actor["prototypeToken"]["width"], expected_dimensions)
                self.assertEqual(actor["prototypeToken"]["height"], expected_dimensions)

    def test_token_size_table_matches_requested_ranges(self):
        self.assertEqual(expected_token_dimensions(None), 1)
        self.assertEqual(expected_token_dimensions(0), 1)
        self.assertEqual(expected_token_dimensions(1), 0.25)
        self.assertEqual(expected_token_dimensions(3), 0.25)
        self.assertEqual(expected_token_dimensions(4), 0.5)
        self.assertEqual(expected_token_dimensions(8), 0.5)
        self.assertEqual(expected_token_dimensions(9), 1)
        self.assertEqual(expected_token_dimensions(22), 1)
        self.assertEqual(expected_token_dimensions(23), 2)
        self.assertEqual(expected_token_dimensions(24), 2)
        self.assertEqual(expected_token_dimensions(25), 3)
        self.assertEqual(expected_token_dimensions(28), 3)
        self.assertEqual(expected_token_dimensions(29), 4)
        self.assertEqual(expected_token_dimensions(33), 4)
        self.assertEqual(expected_token_dimensions(34), 5)


if __name__ == "__main__":
    unittest.main()
